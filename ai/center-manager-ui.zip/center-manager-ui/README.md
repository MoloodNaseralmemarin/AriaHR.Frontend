# Center Manager UI — Standalone Design Deliverable

This folder is a **self-contained set of Angular 20 UI files** for the
AriaHR **Center Manager** role. It was built independently of the AriaHR
repository — no repo files were opened, inspected, or modified — and is
meant to be reviewed now and integrated by you later.

Everything here is **presentation only**: mock data, no HTTP services, no
API calls, no auth/JWT/OTP, no routing module, no changes to
`angular.json` / `package.json` / `tsconfig` / Tailwind config.

## What's inside

```text
center-manager-ui/
├── layout/
│   └── center-layout.component.ts   (reference shell: sidebar + bottom nav + <router-outlet>)
├── shared/
│   ├── models/center-manager.models.ts   (TypeScript interfaces)
│   ├── mock-data/mock-data.ts            (all mock data, separate from UI)
│   ├── utils/status-map.ts               (status → Persian label + badge tone)
│   └── components/
│       ├── status-badge/          (attendance / request / shift status pill)
│       ├── summary-card/          (dashboard & reports stat card)
│       ├── page-header/           (title + subtitle + actions slot)
│       ├── empty-state/           (empty state, doubles as error state)
│       ├── skeleton-loader/       (row & card skeleton loaders)
│       ├── sidebar-nav/           (desktop/tablet navigation)
│       ├── bottom-nav/            (mobile navigation)
│       └── toast/                 (success/error/info toast)
├── dashboard/       → /center/dashboard
├── employees/        → /center/employees
├── attendance/        → /center/attendance
├── shifts/            → /center/shifts
├── requests/          → /center/requests
├── reports/           → /center/reports
├── notifications/     → /center/notifications
└── settings/          → /center/settings
```

Each feature folder follows the same 3-file pattern:
`*.component.ts`, `*.component.html`, `*.component.css` — all standalone
components (`standalone: true`), so they can be imported individually
without any NgModule wiring.

## Design system

- Primary color: professional blue (`blue-600`), white/neutral surfaces,
  subtle borders (`slate-200`), moderate radius (`rounded-xl` /
  `rounded-2xl`), soft shadows (`shadow-sm`), no gradients or heavy
  animation.
- Status colors are consistent everywhere via `shared/utils/status-map.ts`:
  success = emerald, warning = amber, danger = rose, info = sky, neutral = slate.
- Every screen shares the same `app-page-header`, badge, empty/skeleton
  states, and card treatment, so the eight screens read as one system
  rather than eight separate pages.

## RTL & Persian

- The reference shell (`layout/center-layout.component.ts`) sets
  `dir="rtl"` once at the root so every screen inherits correct RTL flow.
  If you integrate screens without using this shell, set `dir="rtl"` on
  your own root/app shell instead.
- All labels are in Persian; Tailwind's logical properties (`ps-*`,
  `pe-*`, `text-start`, `text-end`, `start-*`/`end-*` where used) are
  preferred over `left`/`right` so the layout mirrors correctly.
- Numeric/Latin values (phone numbers, clock times) are wrapped in
  `dir="ltr"` spans/inputs so digits and separators don't reorder.
- Font: the templates reference `'IRANSans', 'Vazirmatn', sans-serif` as
  a fallback stack in `center-layout.component.ts`. Swap this for
  AriaHR's existing Persian font convention when you integrate — the
  repo itself was not accessed to confirm the exact font files/names.

## Responsive behavior

- Mobile-first Tailwind classes throughout; tested breakpoints in mind:
  320 / 375 / 390 / 430 / tablet / desktop.
- Employees and Attendance: a `hidden md:block` table for desktop and a
  `md:hidden` card list for mobile — no squeezed tables on small screens.
- Navigation: `app-sidebar-nav` is `hidden md:flex`; `app-bottom-nav` is
  `md:hidden` and fixed to the bottom with safe-area padding.

## Required UI states

- **Loading** — `app-skeleton-loader` (`variant="row"` for tables,
  `variant="card"` for card grids). Wired up as an example toggle
  (`isLoading` / `viewState()`) in `employees` and `attendance`.
- **Empty** — `app-empty-state`, used for "همه موارد بررسی شده‌اند" on
  the dashboard, empty search results, empty request tabs, and empty
  notifications.
- **Error** — `app-empty-state [isError]="true"` with the exact copy
  requested: "دریافت اطلاعات با مشکل مواجه شد." and a "تلاش مجدد" button,
  demonstrated in `attendance`.
- **Success** — `app-toast`, demonstrated in `requests` (approve/reject)
  and `settings` (save).

## Mock data

All mock data lives in `shared/mock-data/mock-data.ts`, separate from the
components that render it, so it's easy to delete once real services are
wired up. No HTTP client, service class, or API surface was created.

## Integration notes (for later — not done here)

1. Copy the `center-manager-ui/` contents into your Angular workspace
   (e.g. under `src/app/features/center-manager/`).
2. Wire up your own `Routes` array mapping the conceptual routes above
   (`/center/dashboard`, `/center/employees`, …) to each component —
   no routing module is included here.
3. Confirm Tailwind is configured with RTL-friendly logical utilities in
   your project (Tailwind ≥ 3.3 supports `ps-*`/`pe-*`/`start-*`/`end-*`
   out of the box).
4. Replace `shared/mock-data/mock-data.ts` usages with real service
   calls/signals as the backend becomes available; the component
   `@Input`/template contracts won't need to change.
5. Swap the placeholder font stack for AriaHR's actual Persian font.
